#ifndef FAIRYCATREGDIALOG_H
#define FAIRYCATREGDIALOG_H

#include <QDialog>
#include <pushboxgame.h>

namespace Ui {
class FairyCatRegDialog;
}

class FairyCatRegDialog : public QDialog
{
    Q_OBJECT

public:
    explicit FairyCatRegDialog(PushBoxGame *mainGame,QWidget *parent = nullptr);
    ~FairyCatRegDialog();

    PushBoxGame *game;

    //用于判断注册按钮是否可用
    bool l1=false,l2=false,l3=false;

private slots:
    void on_regb_clicked();

    void on_cancelb_clicked();

private:
    Ui::FairyCatRegDialog *ui;

signals:
      void textChanged(QString textChanged);
};

#endif // FAIRYCATREGDIALOG_H
