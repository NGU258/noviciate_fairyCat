#ifndef FAIRYCAT_PUSHBOXWINDOW_H
#define FAIRYCAT_PUSHBOXWINDOW_H

#include <QMainWindow>
#include<QLabel> //不管是导入图片还是文字 都是使用QLabel控件
#include<pushboxgame.h>
#include<fairycatregdialog.h>
#include<fairycatlogindialog.h>

QT_BEGIN_NAMESPACE
namespace Ui {
class FairyCat_PushBoxWindow;
}
QT_END_NAMESPACE

class FairyCat_PushBoxWindow : public QMainWindow
{
    Q_OBJECT

public:
    FairyCat_PushBoxWindow(QWidget *parent = nullptr);
    ~FairyCat_PushBoxWindow();

    //存放20*20张图片
    QLabel *picture[20][20];
    PushBoxGame *game;
    QString defaultUser="ヾ(≧▽≦*)";

    //绑定按键 让角色动起来
    void keyPressEvent(QKeyEvent *event)
    {
        if(event->key()==Qt::Key_W)
            game->up(true);
        else if(event->key()==Qt::Key_S)
            game->down(true);
        else if(event->key()==Qt::Key_A)
            game->left(true);
        else if(event->key()==Qt::Key_D)
            game->right(true);
        else if(event->key()==Qt::Key_Q)
            game->cx();//撤销
        else if(event->key()==Qt::Key_U)
            game->useGhost();//进入隐身状态
        else if(event->key()==Qt::Key_G)
            game->generatorXG();//生成西瓜
    }

private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

    void on_pushButton_3_clicked();

    void on_regb_clicked();

    void on_login_clicked();

    void on_quit_clicked();

    void on_pxb_clicked();

private:
    Ui::FairyCat_PushBoxWindow *ui;
};
#endif // FAIRYCAT_PUSHBOXWINDOW_H
