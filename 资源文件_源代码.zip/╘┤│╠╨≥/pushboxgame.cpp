#include "pushboxgame.h"
#include "qdebug.h"

#include <QFile>
#include<QMessageBox>
#include <QRandomGenerator>
#include<windows.h>

#define FORB(i,l,r) for(int i=l;i<=r;i++)


PushBoxGame::PushBoxGame() {}


// bool PushBoxGame::moveByTeacher(int row,int col,int rowI,int colI)
// {

//     int newRow=row+rowI;
//     int newCol=col+colI;

//     //遇到不是空格(2)或不是目的地(4) 无法移动
//     if(Map[newRow][newCol] !=2 && Map[newRow][newCol] !=4)
//         return false;

//     //箱子
//     if(Map[row][col]==3||Map[row][col]==9)
//     {
//         if(Map[newRow][newCol]==4)
//         {
//             //箱子移到目的地
//             Map[newRow][newCol]=9;
//         }
//         else if(Map[newRow][newCol]==2)
//         {
//             //箱子移到空地
//             Map[newRow][newCol]=3;
//         }
//     }else if(Map[row][col]>=5 && Map[row][col]<=8)
//     {
//         //移动角色 上下左右 5678
//         if(rowI<0&&!colI)
//             Map[newRow][newCol]=5;
//         else if(rowI>0&&!colI)
//             Map[newRow][newCol]=6;
//         else if(!rowI&&colI<0)
//             Map[newRow][newCol]=7;
//         else if(!rowI&&colI>0)
//             Map[newRow][newCol]=8;

//     }

//     emit moved(newCol,newRow,Map[newRow][newCol]);

//     //恢复现场 用原始地图来记录移动前的状态
//     if(Map[row][col]==4||Map[row][col]==9)
//     {
//         OMap[row][col]=4;
//     }else OMap[row][col]=2;

//     emit moved(col,row,OMap[row][col]);

//     return true;
// }

void PushBoxGame::print()
{
    //打印数组 左边：原始地图   右边：游戏地图  地图之间用|分隔
    FORB(row,0,19)
    {
        QString line;

        FORB(col,0,19)
        {
            int ch=OMap[row][col];

            // 空地化成空格
            // QString::number(int num) 将数字转成字符串
            if(ch==0||ch==2)
                line.append("  ");
            else line.append(QString::number(ch)).append(" ");
        }

        line.append(" |  ");

        FORB(col,0,19)
        {
            int ch=Map[row][col];

            //空地化成空格
            if(ch==0||ch==2)
                line.append("  ");
            else line.append(QString::number(ch)).append(" ");
        }

        qDebug()<<line;
    }

    // system("cls");

}


void PushBoxGame::loadMap(int map)
{
    /*
      %数字 是占位符
      %1 表示使用方法的第一个形参
      %2 表示使用方法的第二个形参
      其它同理
      :有点像JAVA中的classpath
    */
    op.clear();


    QString resPath=":/res/map/%1.map";

    //将%1替换成形参map 形成完整路径
    resPath=resPath.arg(map);

    //使用QT的QFile类来读取文件
    QFile file(resPath);

    //打开文件 以只读的形式读取文本文件 成功返回true 失败返回false
    if(file.open(QIODevice::ReadOnly | QIODevice::Text))
    {
        //readAll方法用来读取文件中所有的内容 并保存到Byte数组中
        QByteArray textData=file.readAll();

        //将文件中的所有数据存入到数组中 at方法一次只读取一个数字
        int index(0);
        FORB(row,0,19)
        {
            FORB(col,0,19)
            {
                OMap[row][col]=Map[row][col]=textData.at(index++)-48;
                emit moved(col,row,Map[row][col]);
            }
            //ignore \n
            index++;
        }

    }
    else{
        qDebug()<<"警告！ 警告！ 路径加载失败喵~"<<resPath;
        return ;
    }
}



//要移动的角色： 人或箱子
void PushBoxGame::move(int row ,int col , int rowI,int colI)
{
    //计算物体移动后的新位置
    int newRow=row+rowI;
    int newCol=col+colI;

    //拦截 如果移动后的位置是空地或目的地(2或4) 幽灵状态 则可移动 其它情况无法移动
    if(Map[newRow][newCol]==2||Map[newRow][newCol]==4||Map[newRow][newCol]==100)
    {

        if(Map[row][col]==3&&Map[newRow][newCol]==2)
        {
            Map[newRow][newCol]=3;//箱子移动到空地
            Map[row][col]=2;//原来的位置变成空地

            // move 列 行 元素值
            emit moved(newCol,newRow,Map[newRow][newCol]);
            emit moved(col,row,Map[row][col]);

        }
        else if(Map[row][col]==3&&Map[newRow][newCol]==4)
        {
            Map[newRow][newCol]=9;//箱子移动到目的地 将3标记成9
            Map[row][col]=2;//原来的位置变成空地

            emit moved(newCol,newRow,Map[newRow][newCol]);
            emit moved(col,row,Map[row][col]);

        }
        else if(Map[row][col]==9&&Map[newRow][newCol]==4)
        {
            Map[newRow][newCol]=9;//本身在目的地上
            Map[row][col]=4;//原来的位置变成目的地

            emit moved(newCol,newRow,Map[newRow][newCol]);
            emit moved(col,row,Map[row][col]);

        }
        else if(Map[row][col]==9&&Map[newRow][newCol]==2)
        {

            Map[newRow][newCol]=3;//箱子移出目的地
            Map[row][col]=4;//原来的位置变成目的地

            emit moved(newCol,newRow,Map[newRow][newCol]);
            emit moved(col,row,Map[row][col]);

        }
        else if(Map[row][col]==9||Map[row][col]==4)
        {
            Map[newRow][newCol]=9;//已在目的地中的箱子继续移动到下一个目的地
            Map[row][col]=4; //原来的位置变成目的地

            emit moved(newCol,newRow,Map[newRow][newCol]);
            emit moved(col,row,Map[row][col]);
        }
        else if(Map[row][col]>=5&&Map[row][col]<=8)
        {

            //移动小人 上下左右 5678
            if(rowI<0&&colI==0)
                Map[newRow][newCol]=5;
            else if(rowI>0&&colI==0)
                Map[newRow][newCol]=6;
            else if(rowI==0&&colI<0)
                Map[newRow][newCol]=7;
            else if(rowI==0&&colI>0)
                Map[newRow][newCol]=8;

            emit moved(newCol,newRow,Map[newRow][newCol]);

            Map[row][col]=2;//原位置变成空地
            //解决目的地被角色吞了或角色走了后又生出箱子的情况
            if(OMap[row][col]==4||OMap[row][col]==9)
                Map[row][col]=4; //还原

            emit moved(col,row,Map[row][col]);

        }

        return;
    }
    else return;

}

void PushBoxGame::moveRole(int rowI,int colI)
{
    isMove++;

    //首先找到角色所在的坐标位置
    int row=0,col=0;
    for(int i=0;i<20;i++)
        for(int j=0;j<20;j++)
            if(Map[i][j]>=5&&Map[i][j]<=8)
            {
                row=i;
                col=j;
                goto next;
            }

next:

    //角色移动后的位置
    int newRow=row+rowI;
    int newCol=col+colI;

    //防止越界
    if(newRow<0||newRow>19||newCol<0||newCol>19)
    {
        QMessageBox::information(nullptr,"喵仙小提示","异界危险 请不要越界！！");
        return;
    }

    if(isGhost)
    {
        //移动小人 上下左右 5678

        //遇到空地自动解除隐身状态
        if(Map[newRow][newCol]==2)
            isGhost=!isGhost;

        bool pass=false;
        if(Map[newRow][newCol]==100)
            pass=true;

        if(rowI<0&&colI==0)
            Map[newRow][newCol]=5;
        else if(rowI>0&&colI==0)
            Map[newRow][newCol]=6;
        else if(rowI==0&&colI<0)
            Map[newRow][newCol]=7;
        else if(rowI==0&&colI>0)
            Map[newRow][newCol]=8;

        emit moved(newCol,newRow,Map[newRow][newCol]);

        Map[row][col]=OMap[row][col];

        emit moved(col,row,Map[row][col]);

        if(pass)
        {
            //直接通关
            QMessageBox::information(nullptr,"喵仙小提示","恭喜您通关啦~");
            nextMap();
        }

        if(OMap[row][col]==4)
        {
            Map[row][col]=4; //还原
            emit moved(col,row,Map[row][col]);
        }

        if(OMap[row][col]==3)
        {
            Map[row][col]=3; //还原
            emit moved(col,row,Map[row][col]);
        }

        if(OMap[row][col]==9)
        {
            Map[row][col]=9; //还原
            emit moved(col,row,Map[row][col]);
        }
        return;
    }



    //角色能做的只有三种情况  移到空地2 目的地4 推动箱子(3 9) 吃瓜
    if(Map[newRow][newCol]==2||Map[newRow][newCol]==4||Map[newRow][newCol]==3||Map[newRow][newCol]==9||Map[newRow][newCol]==100)
    {
        //推箱子 3或9
        if(Map[newRow][newCol]==3||Map[newRow][newCol]==9)
            move(newRow,newCol,rowI,colI);
            // moveByTeacher(newRow,newCol,rowI,colI);

        //角色移动
        move(row,col,rowI,colI);
        // moveByTeacher(row,col,rowI,colI);

        if(isPass())
        {
            QMessageBox::information(nullptr,"喵仙小提示","恭喜您通关啦~");
            nextMap();
        }

    }
    else qDebug()<<"无法移动~";
}

void PushBoxGame::nextMap(bool load)
{

    isGhost=false;

    if(load)
        loadMap(++level);

    //发送通关信号
    emit next(level);

}

void PushBoxGame::startGame()
{
    //已进入关卡
    if(level>0)
    {
        //退回到上一关 下次来就是本关 于是就实现了重新开始的效果
        level--;
    }

    nextMap();
}

bool PushBoxGame::isPass()
{
    for(int i=0;i<20;i++)
        for(int j=0;j<20;j++)
            if(Map[i][j]==3)
                return false;
    return true;

}

void PushBoxGame::save(QString info="")
{
    //指定要将状态信息放到啥文件中去 格式
    QSettings set("config.ini",QSettings::IniFormat);

    //格式： 关数：当前关数的游戏状态
    QString data="%1:%2";

    data=data.arg(level);

    QString map;
    for(int i=0;i<20;i++)
        for(int j=0;j<20;j++)
            map.append(QString::number(Map[i][j]));
    data=data.arg(map);

    //如果当前没有传入参数而且用户名不是空的 则说明它是登陆状态 进行拼接 保存进配置文件中
    if(info.isEmpty()&&!user.isEmpty())
    {
        //登陆状态 进行拼接
        info="_%1_%2";
        info=info.arg(user).arg(pwd);
    }

    set.setValue("process"+info,data);

}

bool PushBoxGame::load(QString info="")
{
    QSettings set("config.ini",QSettings::IniFormat);

    //如果当前没有传入参数而且用户名不是空的 则说明它是登陆状态 进行拼接 保存进配置文件中
    if(info.isEmpty()&&!user.isEmpty())
    {
        //登陆状态 进行拼接
        info="_%1_%2";
        info=info.arg(user).arg(pwd);
    }

    QString data=set.value("process"+info).toString();


    if(data.isEmpty())
    {
        return false;
    }

    QString nLevel=data.section(":",0,0);

    QString map=data.section(":",1,1);

    //字符串转整数 将状态进行还原
    level=nLevel.toInt();
    emit next(level);

    //还原原始地图
    loadMap(level);

    //还原游戏地图
    int index=0;
    for(int i=0;i<20;i++)
        for(int j=0;j<20;j++)
        {
            // toLatin1方法是将Qchar 转成 基本字符char
            Map[i][j]=map.at(index++).toLatin1()-48;
            emit moved(j,i,Map[i][j]);
        }

    return true;

}


bool PushBoxGame::reg(QString user ,QString pwd,QString ensurePwd)
{
    QSettings set("config.ini",QSettings::IniFormat);

    if(user.isEmpty())
    {
        QMessageBox::information(nullptr,"喵仙小提示","没有输入用户名喵~");
        return false;
    }

    if(pwd.isEmpty())
    {
        QMessageBox::information(nullptr,"喵仙小提示","没有输入密码喵~");
        return false;
    }

    if(ensurePwd.isEmpty())
    {
        QMessageBox::information(nullptr,"喵仙小提示","请再次确认协会密钥喵~");
        return false;
    }

    if(pwd!=ensurePwd)
    {
        QMessageBox::information(nullptr,"喵仙小提示","输入的密钥与再次确认密钥不一致，请再次检查喵~");
        return false;
    }


    QString key="_%1_%2";
    key=key.arg(user).arg(pwd);

    //如果用户信息已存在
    if(!(set.value("process"+key).toString().isEmpty()))
    {
        QMessageBox::information(nullptr,"喵仙小提示","魔法师协会成员【"+user+"】已在魔法师协会注册过啦 注册失败喵~");
        return false;
    }

    save(key);

    //注册成功后保存用户信息
    this->user=user;
    this->pwd=pwd;

    QMessageBox::information(nullptr,"喵仙小提示","恭喜阁下【"+user+"】成功加入魔法师协会喵~");

    return true;
}

bool PushBoxGame::login(QString user ,QString pwd)
{
    if(user.isEmpty())
    {
        QMessageBox::information(nullptr,"喵仙小提示","没有输入用户名喵~");
        return false;
    }

    if(pwd.isEmpty())
    {
        QMessageBox::information(nullptr,"喵仙小提示","没有输入密码喵~");
        return false;
    }

    QString key="_%1_%2";
    key=key.arg(user).arg(pwd);

    if(!load(key))
    {
        QMessageBox::information(nullptr,"喵仙小提示","用户名或密码输入有误 请重试喵~");
        return false;
    }

    //保存用户信息
    this->user=user;
    this->pwd=pwd;

    return true;

}


void PushBoxGame::restore()
{
    //更新关卡信息
    level=1;
    loadMap(level);

    emit next(level);


    //还原游戏地图
    int index=0;
    for(int i=0;i<20;i++)
        for(int j=0;j<20;j++)
        {
            Map[i][j]=OMap[i][j];
            emit moved(j,i,Map[i][j]);
        }
}

void PushBoxGame::up(bool  add=false)
{
    if(add&&!isGhost)
    {
        op.append("w");
        qDebug()<<op;
    }

    moveRole(-1,0);
    // print();
}

void PushBoxGame::down(bool  add=false)
{

    if(add&&!isGhost)
    {
        op.append("s");
        qDebug()<<op;
    }

    moveRole(1,0);
    // print();
}

void PushBoxGame::left(bool  add=false)
{

    if(add&&!isGhost)
    {
        op.append("a");
        qDebug()<<op;
    }
    moveRole(0,-1);
    // print();
}

void PushBoxGame::right(bool  add=false)
{
    if(add&&!isGhost)
    {
        op.append("d");
        qDebug()<<op;
    }

    moveRole(0,1);
    // print();
}

void PushBoxGame::cx()
{
    //还原地图
    for(int i=0;i<20;i++)
        for(int j=0;j<20;j++)
        {
            Map[i][j]=OMap[i][j];
            emit moved(j,i,Map[i][j]);
        }

    op.chop(1);//删除最后一个字符

    //还原角色移动 在前一步停止
    for(int i=0;i<op.length();i++)
    {
        char ch=op[i].toLatin1();
        if(ch=='w')
            up();
        else if(ch=='s')
            down();
        else if(ch=='a')
            left();
        else if(ch=='d')
            right();
    }

    // qDebug()<<op;
    // qDebug()<<op.length();
    // qDebug()<<op[op.length()];
}

void PushBoxGame::useGhost()
{
    isGhost=!isGhost;

    for(int i=0;i<20;i++)
        for(int j=0;j<20;j++)
            emit moved(j,i,Map[i][j]);
}


void PushBoxGame::generatorXG()
{
    int row=0,col=0;
    while(1)
    {
        row=QRandomGenerator::global()->bounded(20);
        col=QRandomGenerator::global()->bounded(20);

        //角色 目的地 墙与箱子不能变西瓜
        if((Map[row][col]<5||Map[row][col]>8)&&Map[row][col]!=4&&Map[row][col]!=2&&Map[row][col]!=1&&Map[row][col]!=3&&Map[row][col]!=100)
            break;
   }

    qDebug()<<row;
    qDebug()<<col;

    emit moved(col,row,Map[row][col],true);

}


