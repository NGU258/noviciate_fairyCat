#include "fairycat_pushboxwindow.h"

#include <QApplication>
#include<pushboxgame.h>

#include <QRandomGenerator>

auto pushBoxGame()->void
{

    PushBoxGame *game=new PushBoxGame();

    // 加载第一关地图
    game->loadMap(1);

    game->up(false);

    game->print();

    game->down(false);

    game->print();

    game->left(false);

    game->print();

    game->right(false);

    game->print();
}

auto main(int argc, char *argv[])->int
{
    QApplication a(argc, argv);

    FairyCat_PushBoxWindow w;

    w.show();

    // pushBoxGame();

    return a.exec();
}
