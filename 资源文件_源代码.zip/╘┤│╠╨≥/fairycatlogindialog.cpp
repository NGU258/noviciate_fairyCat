#include "fairycatlogindialog.h"
#include "ui_fairycatlogindialog.h"

#include <QMessageBox>

FairyCatLoginDialog::FairyCatLoginDialog(PushBoxGame * winGame,QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::FairyCatLoginDialog)
{
    ui->setupUi(this);

    ui->login->setEnabled(false);

    ui->title->setStyleSheet("QLabel { color: gold; }");
    ui->tt1->setStyleSheet("QLabel { color: red; }");
    ui->tt2->setStyleSheet("QLabel { color: red; }");

    //ui->text1->setStyleSheet("text1 { color: red;  background-color: black;}");
    //ui->text2->setStyleSheet("text2 { color: red;  background-color: black;}");

    // 检测输入框中用户的输入状态
    connect(ui->text1, &QLineEdit::textChanged, [=](QString text) {
        if(!text.isEmpty())
            l1=true;
        else l1=false;

        if(l1&&l2)
            ui->login->setEnabled(true);
        else
            ui->login->setEnabled(false);
    });

    connect(ui->text2, &QLineEdit::textChanged, [=](QString text) {

        if(!text.isEmpty())
            l2=true;
        else l2=false;

        if(l1&&l2)
            ui->login->setEnabled(true);
        else
            ui->login->setEnabled(false);
    });


    //设置显示与 隐藏时的状态
    ui->login->setStyleSheet(R"(
        QPushButton {
            background-color: pink; /* 正常状态的背景颜色 */
        }
        QPushButton:disabled {
            background-color: gray; /* 禁用状态的背景颜色 */
        }
    )");

    this->game=winGame;
}

FairyCatLoginDialog::~FairyCatLoginDialog()
{
    delete ui;
}

void FairyCatLoginDialog::on_login_clicked()
{
    if(game->login(ui->text1->text(),ui->text2->text()))
    {
        game->op.clear();
        QMessageBox::information(nullptr,"喵仙小提示","登陆成功 欢迎回来~");

        accept();
    }
}


void FairyCatLoginDialog::on_cancel_clicked()
{
    reject();
}

