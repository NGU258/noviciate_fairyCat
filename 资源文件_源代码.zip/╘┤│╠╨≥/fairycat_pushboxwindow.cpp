#include "fairycat_pushboxwindow.h"
#include "ui_fairycat_pushboxwindow.h"

#include <QMessageBox>
#include<rank.h>

struct basem{
    QString name;
    int level;
};


FairyCat_PushBoxWindow::FairyCat_PushBoxWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::FairyCat_PushBoxWindow)
{
    ui->setupUi(this);

    //设置窗体背景颜色 按钮字体颜色 文本颜色等
    this->setStyleSheet("QLineEdit {color: green; background-color: black;}"
                        "FairyCat_PushBoxWindow {background-image: url(:/res/imgs/bk5.jpeg); background-position: center;} "
                        "FairyCatRegDialog {background-image: url(:/res/imgs/bk5.jpeg); background-position: center;} "
                        "FairyCatLoginDialog {background-image: url(:/res/imgs/bk5.jpeg); background-position: center;} "
                        "QPushButton { color: purple; background-color: pink;}"
                        "QPushButton: hover { background-color: gold; }"
                        "QLabel { color: green; }"
                        );


    //推箱子控件
    ui->label_2->setStyleSheet("QLabel { color: gold; }");

    //关卡信息控件
    ui->label->setStyleSheet("QLabel { color: green; }");

    //荣誉魔法师
    ui->label_3->setStyleSheet("QLabel { color: red; }");

    //角色名称控件
    ui->text2->setStyleSheet("QLabel { color: red; }");

    //排名信息
    ui->rank->setStyleSheet("QLabel { color: purple; }");

    // ui->
    //设置窗体文字颜色
    // this->setStyleSheet("QWidget {  } }");

    this->show();

    for(int i=0;i<20;i++)
        for(int j=0;j<20;j++)
        {
            picture[i][j]=new QLabel(this);

            //设置图片
            picture[i][j]->setPixmap(QPixmap(":/res/imgs/0.GIF"));

            //设置图片自动缩放
            picture[i][j]->setScaledContents(true);

            //指定所加载的图片大小
            picture[i][j]->setMaximumSize(30,35);

            //将图片添加到控件中去
            ui->gridLayout->addWidget(picture[i][j],i,j);
        }

    game=new PushBoxGame();

    //连接信号 连接游戏中的哪个信号
    //第三个参数需要传入一个槽函数 不过可以使用lambda表达式进行代替
    connect(game,&PushBoxGame::moved,[=](int x,int y,int number,bool xg=false){
        //当number发生变化时
        //更新地图上的图片即可

        QString path=":/res/imgs/%1.GIF";

        //判断是否要隐身
        if(game->isGhost&&number>=5&&number<=8)
            number=number*10+number;

        if(xg)
        {
            number=100;
            game->Map[x][y]=100;
        }


        //偶数关第一张背景 奇数关第二张背景
        if(!(game->level&1)&&!number) //偶数 遇0
            number=10;

        path=path.arg(number);

        picture[y][x]->setPixmap(QPixmap(path));
    });

    connect(game,&PushBoxGame::next,[=](int level){
        ui->label->setText(QString(" 迷 宫 等 级 【Iv %1】 ").arg(level));

        if(!game->user.isEmpty())
        {
            basem base[1000];

            QSettings setting("config.ini",QSettings::IniFormat);
            QStringList ev = setting.allKeys();

            int index = 0;
            foreach (const QString& key, ev) {

                QString data = setting.value(key).toString();
                base[index].level = data.section(":",0,0).toInt();
                base[index].name = key.section("_",1,1);
                index ++;
            }
            std::sort(base,base+index,[&](basem& a,basem& b){
                return a.level > b.level;
            });

            int rk=0;

            for(;rk<index;rk++){
                if(base[rk].name==game->user)
                    break;
            }

            //显示排名
            ui->rank->setText(QString("阁下排名 【%1】").arg(rk+1));
        }
        else ui->rank->setText(QString("阁下排名 【当前未登录 无法查看~】"));


    });



    //默认游戏名
    if(game->user.isEmpty())
        ui->text2->setText(QString("ヾ(≧▽≦*)"));

    //未注册登录前有些按钮可以先不显示
    ui->pushButton->hide();
    ui->pushButton_2->hide();
    ui->pushButton_3->hide();
    ui->quit->hide();
    ui->pxb->hide();
    ui->verticalLayout->update();

    //未注册登录前有些按钮变成灰色无法使用
    // ui->pushButton_2->setEnabled(false);
    // ui->pushButton_3->setEnabled(false);
    // ui->quit->setEnabled(false);



    game->startGame();

}

FairyCat_PushBoxWindow::~FairyCat_PushBoxWindow()
{
    delete ui;
}

void FairyCat_PushBoxWindow::on_pushButton_clicked()
{
    game->startGame();
}


void FairyCat_PushBoxWindow::on_pushButton_2_clicked()
{
    //存档
    game->save("");

    QMessageBox::information(nullptr,"喵仙小提示：","系统保存成功！");

    //刷新排名
    game->nextMap(false);
}


void FairyCat_PushBoxWindow::on_pushButton_3_clicked()
{
    //取档
    game->load("");

    QMessageBox::information(nullptr,"喵仙小提示：","时光回溯成功！");
}


void FairyCat_PushBoxWindow::on_regb_clicked()
{
    FairyCatRegDialog *reg =new FairyCatRegDialog(game,this);

    reg->exec();

    //如果正常返回的话
    if(reg->result()==QDialog::Accepted)
    {
        ui->text2->setText(QString(" ༺๑༺๑%1๑༻๑༻ ").arg(game->user));

        // 注册成功按即可使用游戏正常功能
        // ui->pushButton_2->setEnabled(true);
        // ui->pushButton_3->setEnabled(true);
        // ui->quit->setEnabled(true);

        // 注册成功按即可显示并使用游戏正常功能
        ui->pushButton->show();
        ui->pushButton_2->show();
        ui->pushButton_3->show();
        ui->quit->show();
        ui->pxb->show();
        ui->verticalLayout->update();

        ui->regb->hide();
        ui->login->hide();
        ui->verticalLayout->update();

        game->nextMap(true);
    }
}


void FairyCat_PushBoxWindow::on_login_clicked()
{
    FairyCatLoginDialog *log=new FairyCatLoginDialog(game,this);

    log->exec();

    //如果正常返回的话
    if(log->result()==QDialog::Accepted)
    {
        ui->text2->setText(QString(" ༺๑༺๑%1๑༻๑༻ ").arg(game->user));

        //注册成功按即可使用游戏正常功能
        // ui->pushButton_2->setEnabled(true);
        // ui->pushButton_3->setEnabled(true);
        // ui->quit->setEnabled(true);

        // 注册成功按即可显示并使用游戏正常功能
        ui->pushButton->show();
        ui->pushButton_2->show();
        ui->pushButton_3->show();
        ui->quit->show();
        ui->pxb->show();
        ui->verticalLayout->update();

        ui->regb->hide();
        ui->login->hide();
        ui->verticalLayout->update();

        game->nextMap(true);
    }
}


void FairyCat_PushBoxWindow::on_quit_clicked()
{
    defaultUser="ヾ(≧▽≦*)";

    game->user=game->pwd=nullptr;

    ui->text2->setText(defaultUser);

    game->restore();

    ui->pushButton->hide();
    ui->pushButton_2->hide();
    ui->pushButton_3->hide();
    ui->quit->hide();
    ui->pxb->hide();
    ui->verticalLayout->update();

    ui->regb->show();
    ui->login->show();
    ui->verticalLayout->update();

    // ui->pushButton_2->setEnabled(false);
    // ui->pushButton_3->setEnabled(false);
    // ui->quit->setEnabled(false);

    QMessageBox::information(nullptr,"喵仙小提示：","已退出！ 欢迎下次光临~");

    //刷新排名
    game->nextMap(true);
}


void FairyCat_PushBoxWindow::on_pxb_clicked()
{
    Rank *rank=new Rank(game,this);
    rank->exec();
}

