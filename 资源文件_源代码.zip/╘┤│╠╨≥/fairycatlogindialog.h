#ifndef FAIRYCATLOGINDIALOG_H
#define FAIRYCATLOGINDIALOG_H

#include <QDialog>
#include <pushboxgame.h>
#include <fairycat_pushboxwindow.h>

namespace Ui {
class FairyCatLoginDialog;
}

class FairyCatLoginDialog : public QDialog
{
    Q_OBJECT

public:
    explicit FairyCatLoginDialog(PushBoxGame * winGame,QWidget *parent = nullptr);
    ~FairyCatLoginDialog();

    PushBoxGame * game=nullptr;

    //用于判断注册按钮是否可用
    bool l1=false,l2=false;


private slots:
    void on_login_clicked();

    void on_cancel_clicked();

private:
    Ui::FairyCatLoginDialog *ui;
};

#endif // FAIRYCATLOGINDIALOG_H
