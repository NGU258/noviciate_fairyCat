#include "rank.h"
#include "ui_rank.h"
#include <algorithm>
#include <QVector>
#include <QLabel>


//创建容器
struct basem{
    QString name;
    int level;
};

bool cmp(basem& a,basem& b){
    return a.level > b.level;
}


Rank::Rank(PushBoxGame * game,QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::Rank)
{
    ui->setupUi(this);
    this->game = game;

    this->setStyleSheet(" Rank { alignment: center;  background-image: url(:/res/imgs/bk5.jpeg); background-position: center; } ");


    ui->text1->setStyleSheet("QLabel { color: gold; }");

    basem base[1000];

    QSettings setting("config.ini",QSettings::IniFormat);
    QStringList ev = setting.allKeys();

    int index = 0;
    foreach (const QString& key, ev) {

        QString data = setting.value(key).toString();
        base[index].level = data.section(":",0,0).toInt();
        base[index].name = key.section("_",1,1);
        index ++;
    }
    std::sort(base,base+index,cmp);


    for(int i =0;i<index;i++){

        QLabel* tmp =new QLabel();
        tmp->setStyleSheet("QLabel{color:red; text-align:center; font-size: 31px;font-weight: bold;}");
        tmp->setAlignment(Qt::AlignCenter);
        tmp->setText(QString("第%1名 ༺๑༺๑%3๑༻๑༻༻๑༻  当前迷宫等级Iv.%2 ").arg(i + 1).arg(base[i].level).arg(base[i].name));
        ui->verticalLayout->addWidget(tmp);
    }
}

Rank::~Rank()
{
    delete ui;
}

void Rank::on_pushButton_clicked()
{

    //关闭窗口
    this->reject();
}

