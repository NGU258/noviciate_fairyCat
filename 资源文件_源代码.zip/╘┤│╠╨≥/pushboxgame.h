#ifndef PUSHBOXGAME_H
#define PUSHBOXGAME_H

#include <QKeyEvent>
#include <QObject>
#include<QSettings>
#include <algorithm>
#include <QVector>

class PushBoxGame: public QObject
{
    //槽机制必须有 该宏的支持`
    Q_OBJECT

public:
    //原始地图 用于还原地图状态
    int OMap[20][20]={0};

    //游戏地图
    int Map[20][20]={0};

    //关卡
    int level=0;

    //是否要幽灵附体
    bool isGhost=false;

    //判断是否移动 因为角色初始位置为空地
    int isMove=0;

    //记录用户当前的信息
    QString user;
    QString pwd;

    //记录用户当前的操作序列
    QString op;

public:
    PushBoxGame();

    //开始游戏
    void startGame();

    //加载指定的地图
    void loadMap(int map);

    //判断是否通关
    bool isPass();

    //通关后进入下一关
    void nextMap(bool next=true);

    //人物移动方向 上下左右
    void up(bool  add);
    void down(bool  add);
    void left(bool  add);
    void right(bool  add);

    //打印地图
    void print();

    //移动箱子 （箱子坐标 要移动的方向）
    void move(int row ,int col , int rowI,int colI);

    //移动箱子[老师思路]（箱子坐标 要移动的方向）
    bool moveByTeacher(int row,int col,int rowI,int colI);

    //移动角色
    void moveRole(int rowI,int colI);

    //存档
    void save(QString info);

    //取档
    bool load(QString info);

    //还原
    void restore();

    //撤销
    void cx();

    //幽灵附体~
    void useGhost();

    //随机生成一个西瓜 吃掉它会触发摸鱼阵 可以开始吞噬 吞噬掉所有的箱子即可通关
    void generatorXG();

    //注册
    bool reg(QString user ,QString pwd,QString ensurePwd);

    //登录
    bool login(QString user ,QString pwd);

signals:
    //移动信号  坐标 数值
    void moved(int x,int y,int number,bool xg=false);

    //进入下一关的信号
    void next(int level);

};

#endif // PUSHBOXGAME_H
