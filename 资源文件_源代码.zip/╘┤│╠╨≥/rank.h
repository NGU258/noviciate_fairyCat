#ifndef RANK_H
#define RANK_H

#include <QDialog>
#include <algorithm>
#include <QVector>
#include <pushboxgame.h>

namespace Ui {
class Rank;
}

class Rank : public QDialog
{
    Q_OBJECT

public:
    explicit Rank(PushBoxGame * winGame,QWidget *parent = nullptr);
    ~Rank();

    PushBoxGame * game;

private slots:
    void on_pushButton_clicked();

private:
    Ui::Rank *ui;
};

#endif // RANK_H
