#include "fairycatregdialog.h"
#include "ui_fairycatregdialog.h"

FairyCatRegDialog::FairyCatRegDialog(PushBoxGame *mainGame,QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::FairyCatRegDialog)
{
    ui->setupUi(this);

    //注册按钮 初始时置为灰色
    ui->regb->setEnabled(false);

    ui->title->setStyleSheet("QLabel { color: gold; }");
    ui->tt1->setStyleSheet("QLabel { color: red; }");
    ui->tt2->setStyleSheet("QLabel { color: red; }");
    ui->tt3->setStyleSheet("QLabel { color: red; }");


    // 检测输入框中用户的输入状态
    connect(ui->l1, &QLineEdit::textChanged, [=](QString text) {
        if(!text.isEmpty())
            l1=true;
        else l1=false;

        if(l1&&l2&&l3)
            ui->regb->setEnabled(true);
        else
            ui->regb->setEnabled(false);
    });

    connect(ui->l2, &QLineEdit::textChanged, [=](QString text) {

        if(!text.isEmpty())
            l2=true;
        else l2=false;

        if(l1&&l2&&l3)
            ui->regb->setEnabled(true);
        else
            ui->regb->setEnabled(false);
    });

    connect(ui->l3, &QLineEdit::textChanged, [=](QString text) {
        if(!text.isEmpty())
            l3=true;
        else l3=false;

        if(l1&&l2&&l3)
            ui->regb->setEnabled(true);
        else
            ui->regb->setEnabled(false);
    });



    //设置显示与 隐藏时的状态
    ui->regb->setStyleSheet(R"(
        QPushButton {
            background-color: pink; /* 正常状态的背景颜色 */
        }
        QPushButton:disabled {
            background-color: gray; /* 禁用状态的背景颜色 */
        }
    )");

    //将主窗口传入过来的游戏对象 赋值给对话框
    this->game=mainGame;

}

FairyCatRegDialog::~FairyCatRegDialog()
{
    delete ui;
}

void FairyCatRegDialog::on_regb_clicked()
{
    //注册按钮
    bool isSuccess=game->reg(ui->l1->text(),
              ui->l2->text(),
              ui->l3->text());

    if(isSuccess)
    {
        game->op.clear();
        this->accept();
    }
}


void FairyCatRegDialog::on_cancelb_clicked()
{
    //关闭窗口
    this->reject();
}

